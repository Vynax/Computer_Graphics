#pragma once

//直線方程式 ax + by + c 的 a 跟 b
class Line {
public:
    int a;
    int b;
    int c;
};
